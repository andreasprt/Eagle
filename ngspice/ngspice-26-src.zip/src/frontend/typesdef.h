/*************
 * Header file for typesdef.c
 * 1999 E. Rouat
 ************/

#ifndef ngspice_TYPESDEF_H
#define ngspice_TYPESDEF_H

void com_dftype(wordlist *wl);
void com_stype(wordlist *wl);


#endif
