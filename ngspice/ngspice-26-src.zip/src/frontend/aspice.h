/*************
 * Header file for aspice.c
 * 1999 E. Rouat
 ************/

#ifndef ngspice_ASPICE_H
#define ngspice_ASPICE_H


void com_aspice(wordlist *wl);
void com_jobs(wordlist *wl);
void com_rspice(wordlist *wl);


#endif
