/*************
 * Header file for interp.c
 * 1999 E. Rouat
 ************/

#ifndef ngspice_INTERP_H
#define ngspice_INTERP_H

void lincopy(struct dvec *ov, double *newscale, int newlen, struct dvec *oldscale);


#endif
