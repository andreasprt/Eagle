/*************
 * Header file for quote.c
 * 1999 E. Rouat
 ************/

#ifndef ngspice_QUOTE_H
#define ngspice_QUOTE_H




#endif
