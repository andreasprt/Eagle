/*************
 * Header file for define.c
 * 1999 E. Rouat
 ************/

#ifndef ngspice_DEFINE_H
#define ngspice_DEFINE_H

void com_define(wordlist *wlist);
void com_undefine(wordlist *wlist);


#endif
