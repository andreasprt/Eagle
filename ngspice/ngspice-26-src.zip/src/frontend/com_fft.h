/*************
 * Header file for com_fft.c
 * 2008 H. Vogt
 ************/

#ifndef ngspice_COM_FFT_H
#define ngspice_COM_FFT_H

void com_fft(wordlist *wl);
void com_psd(wordlist *wl);

#endif
