#ifndef ngspice_COM_HARDCOPY_H
#define ngspice_COM_HARDCOPY_H


void com_hardcopy(wordlist *wl);

#endif
