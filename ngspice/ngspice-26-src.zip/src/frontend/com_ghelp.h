#ifndef ngspice_COM_GHELP_H
#define ngspice_COM_GHELP_H


void com_ghelp(wordlist *wl);

#endif

