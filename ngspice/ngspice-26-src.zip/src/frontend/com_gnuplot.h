#ifndef ngspice_COM_GNUPLOT_H
#define ngspice_COM_GNUPLOT_H

void com_gnuplot(wordlist *wl);
void com_write_simple(wordlist *wl);
#endif
