#ifndef ngspice_COM_OPTION_H
#define ngspice_COM_OPTION_H

void com_option(wordlist *wl);

#endif
