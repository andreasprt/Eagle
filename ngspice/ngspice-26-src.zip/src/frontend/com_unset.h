/*************
* Header file for com_unset.c
************/

#ifndef ngspice_COM_UNSET_H
#define ngspice_COM_UNSET_H

#include "ngspice/wordlist.h"

void com_unset(wordlist *wl);

#endif
