/*************
 * Header file for nutmegif.c
 * 1999 E. Rouat
 ************/

#ifndef ngspice_NUTMEGIF_H
#define ngspice_NUTMEGIF_H



#endif
