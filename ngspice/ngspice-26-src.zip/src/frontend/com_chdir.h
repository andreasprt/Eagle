/*************
* Header file for com_chdir.c
************/

#ifndef ngspice_COM_CHDIR_H
#define ngspice_COM_CHDIR_H

#include "ngspice/wordlist.h"

void com_chdir(wordlist *wl);

#endif
