/*************
 * Header file for plotcurv.c
 * 1999 E. Rouat
 ************/

#ifndef ngspice_PLOTCURV_H
#define ngspice_PLOTCURV_H



#endif
