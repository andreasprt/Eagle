/*************
 * Header file for clip.c
 * 1999 E. Rouat
 ************/

#ifndef ngspice_CLIP_H
#define ngspice_CLIP_H



#endif
