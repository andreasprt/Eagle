/*************
 * Header file for runcoms2.c
 * 1999 E. Rouat
 ************/

#ifndef ngspice_RUNCOMS2_H
#define ngspice_RUNCOMS2_H

void com_resume(wordlist *wl);
void com_rset(wordlist *wl);
void com_remcirc(wordlist *wl);

#endif
