/*************
 * Header file for mw_coms.c
 * 1999 E. Rouat
 ************/

#ifndef ngspice_MW_COMS_H
#define ngspice_MW_COMS_H

void com_removecirc(wordlist *wl);


#endif
