#ifndef ngspice_TERMINAL_H
#define ngspice_TERMINAL_H


void outbufputc(void);
void promptreturn(void);


void  term_clear(void);
void  term_home(void);
void  term_cleol(void);
void tcap_init(void);

#endif
