/*************
 * Header file for circuits.c
 * 1999 E. Rouat
 ************/

#ifndef ngspice_CIRCUITS_H
#define ngspice_CIRCUITS_H


struct subcirc {
    char *sc_name;              /* Whatever... */
};


#endif
