/*************
 * Header file for spec.c
 * 1999 E. Rouat
 ************/

#ifndef ngspice_SPEC_H
#define ngspice_SPEC_H

void com_spec(wordlist *wl);

#endif
