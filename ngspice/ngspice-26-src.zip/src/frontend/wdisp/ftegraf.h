/**********
Copyright 1990 Regents of the University of California.  All rights reserved.
Author: 1986 Wayne A. Christopher, U. C. Berkeley CAD Group
**********/

/*
 *
 * Definitions common to the various graphics modules.
 */

#define G_NONE  0
#define G_HCOPY 1
#define G_TERM 2
#define G_MFB   3
#define G_X 4

