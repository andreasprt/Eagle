/*************
 * Header file for where.c
 * 1999 E. Rouat
 ************/

#ifndef ngspice_WHERE_H
#define ngspice_WHERE_H

void com_where(wordlist *wl);


#endif
