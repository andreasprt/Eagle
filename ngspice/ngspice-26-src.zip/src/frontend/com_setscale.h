#ifndef ngspice_COM_SETSCALE_H
#define ngspice_COM_SETSCALE_H

#include "ngspice/wordlist.h"


void com_setscale(wordlist *wl);

#endif
