/*************
* Header file for com_echo.c
************/

#ifndef ngspice_COM_ECHO_H
#define ngspice_COM_ECHO_H

#include "ngspice/wordlist.h"

void com_echo(wordlist *wlist);

#endif
