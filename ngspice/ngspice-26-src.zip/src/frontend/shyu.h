/*************
 * Header file for shyu.c
 * 1999 E. Rouat
 ************/

#ifndef ngspice_SHYU_H
#define ngspice_SHYU_H



#endif
