/*************
 * Header file for fourier.c
 * 1999 E. Rouat
 ************/

#ifndef ngspice_FOURIER_H
#define ngspice_FOURIER_H

void com_fourier(wordlist *wl);
int fourier(wordlist *wl, struct plot *current);

#endif
