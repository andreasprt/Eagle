/*************
 * Header file for lexical.c
 * 1999 E. Rouat
 ************/

#ifndef ngspice_LEXICAL_H
#define ngspice_LEXICAL_H


int input(FILE *fp);


#endif
