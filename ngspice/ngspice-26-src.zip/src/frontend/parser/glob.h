/*************
 * Header file for glob.c
 * 1999 E. Rouat
 ************/

#ifndef ngspice_GLOB_H
#define ngspice_GLOB_H


#endif
