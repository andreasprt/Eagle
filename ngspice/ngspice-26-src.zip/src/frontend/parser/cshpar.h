/*************
 * Header file for cshpar.c
 * 1999 E. Rouat
 ************/

#ifndef ngspice_CSHPAR_H
#define ngspice_CSHPAR_H


#endif
