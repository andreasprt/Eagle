/*************
 * Header file for numparse.c
 * 1999 E. Rouat
 ************/

#ifndef ngspice_NUMPARSE_H
#define ngspice_NUMPARSE_H


#endif
