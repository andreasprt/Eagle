/*************
 * Header file for misccoms.c
 * 1999 E. Rouat
 ************/

#ifndef ngspice_MISCCOMS_H
#define ngspice_MISCCOMS_H

void com_quit(wordlist *wl);
void com_bug(wordlist *wl);
void com_version(wordlist *wl);


#endif
